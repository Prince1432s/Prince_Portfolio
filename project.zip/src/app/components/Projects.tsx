import { ArrowRight } from 'lucide-react';

const projects = [
  {
    title: 'Engineering Management System',
    description: 'A web-based system designed to streamline engineering documents and permits.',
    technologies: ['PHP', 'MySQL', 'Bootstrap'],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=250&fit=crop',
  },
  {
    title: 'School Website Redesign',
    description: 'Modern redesign focused on improving usability and user engagement.',
    technologies: ['Figma', 'UI/UX', 'Web Design'],
    image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=400&h=250&fit=crop',
  },
  {
    title: 'Permit Processing System',
    description: 'Digital platform that simplifies permit application and approval.',
    technologies: ['PHP', 'MySQL', 'JavaScript'],
    image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=400&h=250&fit=crop',
  },
  {
    title: 'Dashboard Design',
    description: 'Analytics dashboard with clean data visualization.',
    technologies: ['Figma', 'UI Design'],
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=250&fit=crop',
  },
  {
    title: 'Mobile App UI',
    description: 'Task management mobile application prototype.',
    technologies: ['Figma', 'Prototyping'],
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400&h=250&fit=crop',
  },
  {
    title: 'Landing Page',
    description: 'High-converting landing page design.',
    technologies: ['HTML', 'CSS', 'JavaScript'],
    image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=400&h=250&fit=crop',
  },
];

export function Projects() {
  return (
    <section className="py-20 px-6 bg-white" id="projects">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          My Projects
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.title}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow"
            >
              <div className="h-48 bg-gray-200 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {project.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <button className="text-black font-medium flex items-center gap-1 hover:gap-2 transition-all text-sm">
                  See Project
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
