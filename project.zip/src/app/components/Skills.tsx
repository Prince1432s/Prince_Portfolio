const designSkills = [
  { name: 'Figma', level: 95 },
  { name: 'Adobe XD', level: 85 },
  { name: 'Wireframing', level: 90 },
];

const codingSkills = [
  { name: 'HTML', level: 92 },
  { name: 'CSS', level: 90 },
  { name: 'JavaScript', level: 80 },
];

const otherTools = [
  { name: 'WordPress', level: 75 },
  { name: 'Bootstrap', level: 88 },
  { name: 'Git', level: 85 },
];

function SkillBar({ name, level }: { name: string; level: number }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-gray-700 font-medium">{name}</span>
        <span className="text-gray-500 text-sm">{level}%</span>
      </div>
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-black rounded-full transition-all duration-1000"
          style={{ width: `${level}%` }}
        />
      </div>
    </div>
  );
}

export function Skills() {
  return (
    <section className="py-20 px-6 bg-gray-50" id="skills">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          My Skills
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Design Skills</h3>
            <div className="space-y-6">
              {designSkills.map((skill) => (
                <SkillBar key={skill.name} {...skill} />
              ))}
            </div>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Coding Skills</h3>
            <div className="space-y-6">
              {codingSkills.map((skill) => (
                <SkillBar key={skill.name} {...skill} />
              ))}
            </div>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Other Tools</h3>
            <div className="space-y-6">
              {otherTools.map((skill) => (
                <SkillBar key={skill.name} {...skill} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
