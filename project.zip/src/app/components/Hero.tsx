import { Download } from 'lucide-react';
import profileImg from '../../imports/692063290_961150079998991_1897046471854234383_n.jpg';

export function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 pt-24 pb-20 bg-gray-50" id="home">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900">
              Prince John Maglangit
            </h1>
            <h2 className="text-xl md:text-2xl text-gray-700">
              UI/UX Designer & Information Systems Student
            </h2>
          </div>

          <p className="text-gray-600 leading-relaxed max-w-xl">
            I design and develop modern, user-centered digital experiences that combine creativity, functionality, and clean visual design. Passionate about UI/UX and technology, I create intuitive and responsive interfaces that deliver meaningful user experiences.
          </p>

          <div className="flex flex-wrap gap-4 pt-4">
            <button className="px-8 py-3 bg-black text-white rounded-md font-medium hover:bg-gray-800 transition-colors">
              View My Work
            </button>

            <button className="px-8 py-3 border-2 border-black text-black rounded-md font-medium hover:bg-black hover:text-white transition-colors">
              Hire Me
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center">
          <div className="relative w-80 h-80">
            <div className="w-full h-full rounded-full overflow-hidden border-4 border-gray-200 shadow-xl bg-white">
              <img
                src={profileImg}
                alt="Prince John Maglangit"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
