export function Footer() {
  return (
    <footer className="py-8 px-6 bg-gray-50 border-t border-gray-200">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-gray-600 text-sm">
          © 2026 Prince John Maglangit. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
