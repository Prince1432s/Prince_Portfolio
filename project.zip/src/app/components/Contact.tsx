import { Mail, Phone, MapPin, Send } from 'lucide-react';

export function Contact() {
  return (
    <section className="py-20 px-6 bg-white" id="contact">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-4">
          Contact Me
        </h2>
        <p className="text-center text-gray-600 mb-16 max-w-2xl mx-auto">
          Have a project idea or collaboration in mind? Feel free to reach out. I'd love to connect!
        </p>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center text-white mx-auto mb-4">
              <Mail size={24} />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Email</h3>
            <p className="text-gray-600 text-sm break-all">princejohnmalgangit1@gmail.com</p>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center text-white mx-auto mb-4">
              <Phone size={24} />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Phone</h3>
            <p className="text-gray-600 text-sm">+63 9070376643</p>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center text-white mx-auto mb-4">
              <MapPin size={24} />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">Location</h3>
            <p className="text-gray-600 text-sm">Panabo City, Philippines</p>
          </div>
        </div>

        <div className="max-w-2xl mx-auto bg-gray-50 rounded-lg p-8">
          <form className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 rounded-md bg-white border border-gray-200 focus:border-black outline-none transition-colors text-gray-900 placeholder:text-gray-500"
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 rounded-md bg-white border border-gray-200 focus:border-black outline-none transition-colors text-gray-900 placeholder:text-gray-500"
              />
            </div>
            <input
              type="text"
              placeholder="Subject"
              className="w-full px-4 py-3 rounded-md bg-white border border-gray-200 focus:border-black outline-none transition-colors text-gray-900 placeholder:text-gray-500"
            />
            <textarea
              placeholder="Your Message"
              rows={6}
              className="w-full px-4 py-3 rounded-md bg-white border border-gray-200 focus:border-black outline-none transition-colors resize-none text-gray-900 placeholder:text-gray-500"
            ></textarea>
            <button
              type="submit"
              className="w-full px-8 py-3 bg-black hover:bg-gray-800 text-white rounded-md font-medium flex items-center justify-center gap-2 transition-colors"
            >
              Send Message
              <Send size={18} />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
