import { GraduationCap, Award, Code } from 'lucide-react';

const experiences = [
  {
    icon: GraduationCap,
    title: 'Bachelor of Science in Information Systems',
    organization: 'Davao del Norte State College',
    period: '2024 – Present',
  },
  {
    icon: Award,
    title: 'UI/UX Design Workshop',
    organization: 'Completed workshops focused on user interface design principles and wireframing.',
    period: '2024',
  },
  {
    icon: Code,
    title: 'Web Development Training',
    organization: 'Learned modern web technologies and responsive design practices.',
    period: '2023',
  },
];

export function Experience() {
  return (
    <section className="py-20 px-6 bg-gray-50" id="experience">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          Experience & Education
        </h2>

        <div className="space-y-6">
          {experiences.map((exp) => (
            <div
              key={exp.title}
              className="bg-white rounded-lg p-8 border border-gray-200 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center text-white flex-shrink-0">
                  <exp.icon size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {exp.title}
                  </h3>
                  <p className="text-gray-600 mb-2 leading-relaxed">
                    {exp.organization}
                  </p>
                  <p className="text-gray-500 text-sm font-medium">
                    {exp.period}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
