import { MapPin } from 'lucide-react';

export function About() {
  return (
    <section className="py-20 px-6 bg-white" id="about">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          About Me
        </h2>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="text-center p-8 bg-gray-50 rounded-lg">
            <div className="text-5xl font-bold text-gray-900 mb-2">2+</div>
            <p className="text-gray-600">Years Experience</p>
          </div>

          <div className="text-center p-8 bg-gray-50 rounded-lg">
            <div className="text-5xl font-bold text-gray-900 mb-2">15+</div>
            <p className="text-gray-600">Completed Projects</p>
          </div>

          <div className="text-center p-8 bg-gray-50 rounded-lg flex flex-col items-center justify-center">
            <MapPin className="w-6 h-6 text-gray-700 mb-2" />
            <p className="text-gray-700">Carmen, Davao del Norte</p>
          </div>
        </div>

        <p className="text-center text-gray-600 leading-relaxed max-w-4xl mx-auto">
          I have 2+ years of experience in UI/UX design, prototyping, and creating interactive user interface designs using Figma. As an Information Systems student, I'm passionate about web development and digital creativity. I specialize in creating modern, user-centered interfaces and functional digital solutions that improve user experience.
        </p>
      </div>
    </section>
  );
}
